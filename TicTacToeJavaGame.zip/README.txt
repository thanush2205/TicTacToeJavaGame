🕹️ Tic-Tac-Toe Java Game

Instructions to Run:
----------------------
1. Make sure Java is installed.
   - Run: java -version

2. Download and extract the folder.

3. Run the game:
   - On Windows: double-click `run.bat` or run `java -jar TicTacToeGame.jar`
   - On Linux/Mac: run `sh run.sh` or `java -jar TicTacToeGame.jar`

Enjoy the game!
