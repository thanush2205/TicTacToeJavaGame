#!/bin/bash
java -jar TicTacToeGame.jar
